<article id="post-not-found" class="hentry">
  <header class="article-header">
    <h1><?php _e("Oops, Post Not Found!", "jointstheme"); ?></h1>
  </header>
  <section class="entry-content">
    <p><?php _e("Uh Oh. Something is missing. Try double checking things.", "jointstheme"); ?></p>
  </section>
  <footer class="article-footer">
      <p><?php _e("This is the error message in the parts/missing-content.php template.", "jointstheme"); ?></p>
  </footer>
</article>