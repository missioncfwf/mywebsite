<?php
/**
 * @package WordPress
 * @subpackage HTML5-Reset-WordPress-Theme
 * @since HTML5 Reset 2.0
 */
 get_header(); ?>

	<h2><?php _e('Error 404 - Page Not Found','html5reset'); ?></h2>

<?php get_sidebar(); ?>

<?php get_footer(); ?>