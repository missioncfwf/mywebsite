SiteName : <your URL here>
ThemeName Documentation : <your URL here >

! IMPORTANT !
Before anything else is initiated in the setup of this theme, you must immediately do the following
FAILURE TO FOLLOW THESE DIRECTIONS WILL PRODUCE UNEXPECTED RESULTS



DEFAULT ABILITIES

1. [ Start your list here ]



FILE HIERARCHY

1.  index.php       ================================ contains feed for recent posts w/out sidebar

2.  single.php      ================================ strictly for displaying single posts w/sidebar

3.  page.php        ================================ individual page w/out a sidebar

4.  sidebar.php     ================================ dynamic widget area w/defaults

5.  search.php      ================================ displays search results w/sidebar

6.  archive.php     ================================ displays post archive results for either month, year, dayor tag w/sidebar

7.  category.php    ================================ displays post categories archive w/sidebar

8.  comments.php    ================================ displays user comments and loads theme's comment respond form

9.  404.php         ================================ displays customized 404 error page w/out sidebar

10. pageblank.php   ================================ a custom blank page w/out sidebar



DEFICIENCIES

1. [ Start your list here ]



SPECIAL REQUIREMENTS

1. [ Start your list here ]



SUPPORT & UPDATES

Author Support: <your contact info here>
Author URI: <your URL here>