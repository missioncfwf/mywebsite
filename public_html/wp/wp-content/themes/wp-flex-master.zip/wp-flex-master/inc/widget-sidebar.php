<aside id="sidebar" role="complementary">
  <?php get_sidebar(); ?>
</aside>