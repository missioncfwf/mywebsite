<small class="meta">
  <span>posted by: <?php the_author(); ?></span> on <time datetime="%3$s"><a href="<?php the_permalink(); ?>"><?php the_time( get_option( 'date_format' ) ); ?></a></time>
</small>