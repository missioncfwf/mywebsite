<?php
  add_editor_style();
?>