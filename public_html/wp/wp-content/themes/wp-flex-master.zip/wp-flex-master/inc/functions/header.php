<?php
  define( 'HEADER_TEXTCOLOR', '' );
  define( 'HEADER_IMAGE', '' ); // %s is the template dir uri || %s/img/default_header.jpg
  define( 'HEADER_IMAGE_WIDTH', 775 ); // use width and height appropriate for your theme
  define( 'HEADER_IMAGE_HEIGHT', 200 );
?>