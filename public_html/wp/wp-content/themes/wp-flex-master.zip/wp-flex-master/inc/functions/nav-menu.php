<?php
// /*-----------------------------------[ register the custom nav menu(s) ] */

// // This will take additonal objects for another custom nav menu
// //
// // 'primary' => 'Primary Menu',
// // 'footer'  => 'Footer Menu'
// register_nav_menus( array(
//     'primary'   => 'Primary Menu'
// ));
?>