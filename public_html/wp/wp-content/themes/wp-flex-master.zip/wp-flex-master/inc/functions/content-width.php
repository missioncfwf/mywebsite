<?php
  if ( ! isset( $content_width ) ) :
    $content_width = 960;
  endif;
?>