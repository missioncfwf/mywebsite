<footer class="entry-footer">
  <?php get_template_part( 'inc/comment-count' ); ?>
  <?php get_template_part( 'inc/taxonomy' ); ?>
</footer>