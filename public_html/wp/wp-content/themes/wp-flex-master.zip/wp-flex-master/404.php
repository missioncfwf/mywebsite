<?php get_header(); ?>
  <main class="clearfix" id="content" role="main">
    <h2>Error 404 - Page Not Found</h2>
  </main>

  <aside id="sidebar" role="complementary">
    <?php get_sidebar(); ?>
  </aside>
<?php get_footer(); ?>