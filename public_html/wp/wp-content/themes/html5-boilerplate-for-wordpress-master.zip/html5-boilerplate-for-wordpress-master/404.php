<?php
/**
 * @package WordPress
 * @subpackage HTML5_Boilerplate
 */

get_header(); ?>

  <div id="main" role="main">

    <details>
      <summary><h1>Not found</h1></summary>
      <p><span frown>:(</span></p>
    </details>

  </div>

<?php get_sidebar(); ?>

<?php get_footer(); ?>